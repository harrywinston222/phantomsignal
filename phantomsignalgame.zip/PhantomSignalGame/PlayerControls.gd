extends Spatial

func _ready():
	# 1. SUNLIGHT
	var sun = DirectionalLight.new()
	sun.rotation_degrees = Vector3(-45, 45, 0)
	add_child(sun)
	
	# 2. FLOOR BLOCK
	var floor_block = CSGBox.new()
	floor_block.size = Vector3(40.0, 5.0, 40.0)
	floor_block.use_collision = true
	var floor_mat = SpatialMaterial.new()
	floor_mat.albedo_color = Color(0.12, 0.13, 0.16) 
	floor_block.material = floor_mat
	add_child(floor_block) 
	
	# 3. COMBAT BARRICADES
	for i in range(15):
		var wall = CSGBox.new()
		var w = randf_range(2.0, 5.0)
		var h = randf_range(2.0, 4.0)
		wall.size = Vector3(w, h, 1.5)
		wall.use_collision = true
		var random_x = randf_range(-15.0, 15.0)
		var random_z = randf_range(-15.0, 15.0)
		wall.translation = Vector3(random_x, h / 2.0, random_z)
		var wall_material = SpatialMaterial.new()
		wall_material.albedo_color = Color(0.3, 0.33, 0.38)
		wall.material = wall_material
		add_child(wall)

	# 4. KINEMATIC PLAYER
	var player = KinematicBody.new()
	player.name = "Player"
	player.translation = Vector3(0.0, 15.0, 0.0)
	add_child(player)
	
	var collision = CollisionShape.new()
	var capsule = CapsuleShape.new()
	capsule.radius = 0.4
	capsule.height = 1.8
	collision.shape = capsule
	collision.rotation_degrees.x = 90
	player.add_child(collision)
	
	var camera = Camera.new()
	camera.name = "Camera"
	camera.translation = Vector3(0.0, 1.5, 0.0)
	camera.current = true
	player.add_child(camera)
	
	# Rifle Frame
	var gun = CSGBox.new()
	gun.size = Vector3(0.1, 0.15, 0.9)
	gun.translation = Vector3(0.3, -0.3, -0.6)
	var gun_mat = SpatialMaterial.new()
	gun_mat.albedo_color = Color(0.2, 0.22, 0.25)
	gun_mat.metallic = 0.8
	gun.material = gun_mat
	camera.add_child(gun)

	player.set_script(PlayerControlsScript)

func randf_range(from: float, to: float) -> float:
	return randf() * (to - from) + from

# --- CLEAN CONTROLS SYSTEM ---
class_name MobileFPSGame

class PlayerControlsScript extends KinematicBody:
	const RUN_SPEED = 5.0
	const TOUCH_SENSITIVITY = 0.005
	const GRAVITY = 12.0

	var camera_node : Camera
	var gravity_vector = Vector3.ZERO

	func _ready():
		camera_node = get_node_or_null("Camera")
		# Keep mouse visible for absolute system safety
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)

	func _physics_process(delta):
		var move_direction = Vector3.ZERO
		
		# TABLET TOUCH MOVEMENT BLOCK: Auto-walk forward if tapping the left-side touchscreen half
		if Input.is_mouse_button_pressed(BUTTON_LEFT):
			var touch_position = get_viewport().get_mouse_position()
			if touch_position.x < get_viewport().size.x / 2:
				move_direction -= transform.basis.z
		
		var velocity = move_direction.normalized() * RUN_SPEED
		if not is_on_floor():
			gravity_vector.y -= GRAVITY * delta
		else:
			gravity_vector.y = 0
				
		velocity.y = gravity_vector.y
		move_and_slide(velocity, Vector3.UP)

	func _input(event):
		# TABLET TOUCH LOOK BLOCK: Dragging fingers on screen rotates look gaze line
		if event is InputEventMouseMotion and Input.is_mouse_button_pressed(BUTTON_LEFT):
			var touch_position = get_viewport().get_mouse_position()
			# Gaze look drag tracking happens on the right side screen split area
			if touch_position.x > get_viewport().size.x / 2:
				rotate_y(-event.relative.x * TOUCH_SENSITIVITY)
				if camera_node:
					camera_node.rotate_x(-event.relative.y * TOUCH_SENSITIVITY)
					camera_node.rotation.x = clamp(camera_node.rotation.x, deg2rad(-85), deg_to_rad(85))
